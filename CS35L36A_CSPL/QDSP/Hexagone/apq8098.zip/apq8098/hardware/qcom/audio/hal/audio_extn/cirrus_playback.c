/*
 * Copyright (c) 2016, Cirrus Logic Inc
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of The Linux Foundation nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#define LOG_TAG "audio_hw_cirrus_playback"
/*#define LOG_NDEBUG 0*/
#define LOG_NDDEBUG 0

#include <errno.h>
#include <math.h>
#include <cutils/log.h>
#include <fcntl.h>
#include "../audio_hw.h"
#include "platform.h"
#include "platform_api.h"
#include <sys/stat.h>
#include <linux/types.h>
#include <linux/ioctl.h>
#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <cutils/properties.h>
#include "audio_extn.h"

#ifdef CIRRUS_PLAYBACK_ENABLED	/* Defined in audio_extn.h; remove to turn off */

struct cirrus_playback_session {
	void *adev_handle;
	pthread_mutex_t fb_prot_mutex;
	pthread_mutex_t calibration_mutex;
	pthread_t initialization_thread;
	pthread_t failure_detect_thread;
	struct pcm *pcm_rx;
	struct pcm *pcm_tx;
	volatile int32_t state;
};

enum cirrus_playback_state {
	INIT = 0,
	CALIBRATING = 1,
	IDLE = 2,
	PLAYBACK = 3
};

struct crus_sp_ioctl_header {
	uint32_t size;
	uint32_t module_id;
	uint32_t param_id;
	uint32_t data_length;
	void *data;
};

/* Payload struct for getting calibration result from DSP module */
struct cirrus_cal_result_t {
	int32_t status_l;
	int32_t checksum_l;
	int32_t z_l;
	int32_t status_r;
	int32_t checksum_r;
	int32_t z_r;
};

/* Payload struct for setting the RX and TX use cases */
struct crus_rx_run_case_ctrl_t {
	int32_t value;
	int32_t status_l;
	int32_t checksum_l;
	int32_t z_l;
	int32_t status_r;
	int32_t checksum_r;
	int32_t z_r;
	int32_t atemp;
};

/* Payload struct for reading live temperature & imepdance */
struct crus_rx_get_temp_t {
	uint32_t cal_status_l;
	uint32_t temp_r;
	uint32_t cal_z_r;
	uint32_t temp_l;
	uint32_t cal_z_l;
	uint32_t cal_status_r;
	uint32_t cal_amb_temp_l;
	uint32_t reserved[2];
	uint32_t cal_cksum_r;
	uint32_t cal_amb_temp_r;
	uint32_t cal_cksum_l;
	uint32_t cal_status_hp_l;
	uint32_t cal_status_full_l;
	uint32_t cal_status_hp_r;
	uint32_t cal_status_full_r;
};

#define CRUS_SP_FILE		"/dev/msm_cirrus_playback"
#define CRUS_CAL_FILE		"/data/misc/audio/audio.cal"
#define CRUS_TX_CONF_FILE	"/etc/firmware/crus_sp_tx%d.bin"
#define CRUS_RX_CONF_FILE	"/etc/firmware/crus_sp_rx%d.bin"

#define CRUS_SP_USECASE_MIXER	"Cirrus SP Usecase"
#define CRUS_SP_LOAD_CONF_MIXER	"Cirrus SP Load Config"
#define CRUS_SP_FAIL_DET_MIXER	"Cirrus SP Failure Detection"
#define CRUS_SP_PROT_EN_MIXER	"Cirrus SP Protection"
#define CRUS_SP_AMB_TEMP_MIXER	"Cirrus SP Ambient Temperature"

#define CIRRUS_SP		0x10027053

#define CRUS_MODULE_ID_TX	0x00000002
#define CRUS_MODULE_ID_RX	0x00000001

#define CRUS_PARAM_RX_SET_USECASE	0x00A1AF02
#define CRUS_PARAM_TX_SET_USECASE	0x00A1BF0A

#define CRUS_PARAM_RX_SET_CALIB		0x00A1AF03
#define CRUS_PARAM_TX_SET_CALIB		0x00A1BF03

#define CRUS_PARAM_RX_SET_EXT_CONFIG	0x00A1AF05
#define CRUS_PARAM_TX_SET_EXT_CONFIG	0x00A1BF08

#define CRUS_PARAM_RX_GET_TEMP		0x00A1AF07
#define CRUS_PARAM_TX_GET_TEMP_CAL	0x00A1BF06

#define CRUS_AFE_PARAM_ID_ENABLE	0x00010203

#define CRUS_AFE_MAX_PARAMS	384

#define FAIL_DETECT_INIT_WAIT	500000
#define FAIL_DETECT_LOOP_WAIT	300000

#define CRUS_DEFAULT_CAL_L	0x2A11
#define CRUS_DEFAULT_CAL_R	0x29CB

#define CRUS_SP_IOCTL_MAGIC	'a'

#define CRUS_SP_IOCTL_GET	_IOWR(CRUS_SP_IOCTL_MAGIC, 219, void *)
#define CRUS_SP_IOCTL_SET	_IOWR(CRUS_SP_IOCTL_MAGIC, 220, void *)

#ifdef CIRRUS_TDM

static struct pcm_config pcm_config_cirrus_tx = {
	.channels = 2,
	.rate = 48000,
	.period_size = 320,
	.period_count = 4,
	.format = PCM_FORMAT_S16_LE,
	.start_threshold = 0,
	.stop_threshold = INT_MAX,
	.avail_min = 0,
};

static struct pcm_config pcm_config_cirrus_rx = {
	.channels = 8,
	.rate = 48000,
	.period_size = 320,
	.period_count = 4,
	.format = PCM_FORMAT_S32_LE,
	.start_threshold = 0,
	.stop_threshold = INT_MAX,
	.avail_min = 0,
};

#else

static struct pcm_config pcm_config_cirrus_tx = {
	.channels = 2,
	.rate = 48000,
	.period_size = 256,
	.period_count = 4,
	.format = PCM_FORMAT_S16_LE,
	.start_threshold = 0,
	.stop_threshold = INT_MAX,
	.avail_min = 0,
};

static struct pcm_config pcm_config_cirrus_rx = {
	.channels = 2,
	.rate = 48000,
	.period_size = 256,
	.period_count = 4,
	.format = PCM_FORMAT_S16_LE,
	.start_threshold = 0,
	.stop_threshold = INT_MAX,
	.avail_min = 0,
};

#endif

static struct cirrus_playback_session handle;

void *audio_extn_cirrus_initialization_thread();
void *audio_extn_cirrus_failure_detect_thread();

void audio_extn_cirrus_playback_init(void *adev)
{
	memset(&handle, 0, sizeof(handle));
	if (!adev) {
		ALOGE("%s: Invalid params", __func__);
		return;
	}

	handle.adev_handle = adev;
	handle.state = INIT;

	pthread_mutex_init(&handle.fb_prot_mutex, NULL);
	pthread_mutex_init(&handle.calibration_mutex, NULL);

	ALOGI("%s: Initialize Cirrus Logic Playback module", __func__);

	(void)pthread_create(&handle.initialization_thread,
			     (const pthread_attr_t *) NULL,
			     audio_extn_cirrus_initialization_thread, &handle);
}

int audio_extn_cirrus_run_calibration()
{
	struct audio_device *adev = handle.adev_handle;
	struct crus_sp_ioctl_header header;
	struct cirrus_cal_result_t result;
	struct crus_rx_run_case_ctrl_t case_ctrl;
	struct mixer_ctl *ctl_temp;
	FILE *cal_file;
	int ret = 0, dev_file;
	char buffer[128];
	uint32_t option, atemp;

	ALOGI("%s: Running speaker calibration", __func__);

	cal_file = fopen(CRUS_CAL_FILE, "r");
	if (cal_file) {
		ret = fread(buffer, 1, sizeof(result), cal_file);
		if (ret < 0) {
			ALOGE("%s: Cirrus SP calibration file cannot be read (%d)",
			      __func__, ret);
			fclose(cal_file);
			ret = -EINVAL;
			goto exit;
		}

		memcpy(&result, buffer, sizeof(result));
		fclose(cal_file);
	} else {
		dev_file = open(CRUS_SP_FILE, O_RDWR | O_NONBLOCK);
		if (dev_file < 0) {
			ALOGE("%s: Failed to open Cirrus Playback IOCTL (%d)",
			      __func__, dev_file);
			ret = -EINVAL;
			goto exit;
		}

		ALOGI("%s: Calibrating...", __func__);

		option = 1;

		header.size = sizeof(header);
		header.module_id = CRUS_MODULE_ID_RX;
		header.param_id = CRUS_PARAM_RX_SET_CALIB;
		header.data_length = sizeof(option);
		header.data = &option;

		ret = ioctl(dev_file, CRUS_SP_IOCTL_SET, &header);
		if (ret < 0) {
			ALOGE("%s: Cirrus SP calibration IOCTL failure (%d)",
			      __func__, ret);
			close(dev_file);
			ret = -EINVAL;
			goto exit;
		}

		header.size = sizeof(header);
		header.module_id = CRUS_MODULE_ID_TX;
		header.param_id = CRUS_PARAM_TX_SET_CALIB;
		header.data_length = sizeof(option);
		header.data = &option;

		ret = ioctl(dev_file, CRUS_SP_IOCTL_SET, &header);
		if (ret < 0) {
			ALOGE("%s: Cirrus SP calibration IOCTL failure (%d)",
			      __func__, ret);
			close(dev_file);
			ret = -EINVAL;
			goto exit;
		}

		sleep(2);

		header.size = sizeof(header);
		header.module_id = CRUS_MODULE_ID_TX;
		header.param_id = CRUS_PARAM_TX_GET_TEMP_CAL;
		header.data_length = sizeof(result);
		header.data = &buffer;

		ret = ioctl(dev_file, CRUS_SP_IOCTL_GET, &header);
		if (ret < 0) {
			ALOGE("%s: Cirrus SP calibration IOCTL failure (%d)",
			      __func__, ret);
			close(dev_file);
			ret = -EINVAL;
			goto exit;
		}

		close(dev_file);

		memcpy(&result, buffer, sizeof(result));

		if (result.status_l != 1)
			ALOGE("%s: Left calibration failure. Please check speakers",
			      __func__);

		if (result.status_r != 1)
			ALOGE("%s: Right calibration failure. Please check speakers",
			      __func__);

		if ((result.status_l != 1) || (result.status_r != 1)) {
			ret = -EINVAL;
			goto exit;
		}

		cal_file = fopen(CRUS_CAL_FILE, "wb");
		if (cal_file == NULL) {
			ALOGE("%s: Cannot create Cirrus SP calibration file (%s)",
			      __func__, strerror(errno));
			ret = -EINVAL;
			goto exit;
		}

		ret = fwrite(&buffer, 1, sizeof(result), cal_file);
		if (ret < 0) {
			ALOGE("%s: Unable to save Cirrus SP calibration data (%d)",
			      __func__, ret);
			fclose(cal_file);
			ret = -EINVAL;
			goto exit;
		}

		fclose(cal_file);

		ALOGI("%s: Cirrus calibration file successfully written",
		      __func__);
	}

	dev_file = open(CRUS_SP_FILE, O_RDWR | O_NONBLOCK);
	if (dev_file < 0) {
		ALOGE("%s: Failed to open Cirrus Playback IOCTL (%d)",
		      __func__, dev_file);
		ret = -EINVAL;
		goto exit;
	}

	ctl_temp = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_AMB_TEMP_MIXER);
	atemp = mixer_ctl_get_value(ctl_temp, 0);

	case_ctrl.status_l = 1;
	case_ctrl.status_r = 1;
	case_ctrl.z_l = result.z_l;
	case_ctrl.z_r = result.z_r;
	case_ctrl.checksum_l = result.z_l + 1;
	case_ctrl.checksum_r = result.z_r + 1;
	case_ctrl.atemp = atemp;
	case_ctrl.value = 0;

	header.size = sizeof(header);
	header.module_id = CRUS_MODULE_ID_TX;
	header.param_id = CRUS_PARAM_TX_SET_USECASE;
	header.data_length = sizeof(case_ctrl.value);
	header.data = &(case_ctrl.value);

	ret = ioctl(dev_file, CRUS_SP_IOCTL_SET, &header);
	if (ret < 0) {
		ALOGE("%s: Cirrus SP calibration IOCTL failure (%d)", __func__, ret);
		close(dev_file);
		ret = -EINVAL;
		goto exit;
	}

	header.size = sizeof(header);
	header.module_id = CRUS_MODULE_ID_RX;
	header.param_id = CRUS_PARAM_RX_SET_USECASE;
	header.data_length = sizeof(case_ctrl);
	header.data = &case_ctrl;

	ret = ioctl(dev_file, CRUS_SP_IOCTL_SET, &header);
	if (ret < 0) {
		ALOGE("%s: Cirrus SP calibration IOCTL failure (%d)", __func__, ret);
		close(dev_file);
		ret = -EINVAL;
		goto exit;
	}

	sleep(1);

	header.size = sizeof(header);
	header.module_id = CRUS_MODULE_ID_RX;
	header.param_id = CRUS_PARAM_RX_GET_TEMP;
	header.data_length = ARRAY_SIZE(buffer);
	header.data = buffer;

	ret = ioctl(dev_file, CRUS_SP_IOCTL_GET, &header);
	if (ret < 0) {
		ALOGE("%s: Cirrus SP temperature IOCTL failure (%d)", __func__, ret);
		close(dev_file);
		ret = -EINVAL;
		goto exit;
	}

	close(dev_file);

	ALOGI("%s: Cirrus SP successfully calibrated", __func__);
exit:
	ALOGI("%s: Exit", __func__);

	if (ret < 0)
		return ret;

	return 0;
}

int audio_extn_cirrus_load_usecase_configs()
{
	struct audio_device *adev = handle.adev_handle;
	struct mixer_ctl *ctl_uc, *ctl_config, *ctl_prot;
	bool prot_en;
	char filename[128];
	int ret = 0, num_uc, default_uc, i;

	ALOGI("%s: Loading usecase tuning configs", __func__);

	ctl_uc = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_USECASE_MIXER);
	ctl_config = mixer_get_ctl_by_name(adev->mixer,
					   CRUS_SP_LOAD_CONF_MIXER);
	ctl_prot = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_PROT_EN_MIXER);
	if (!ctl_uc || !ctl_config || !ctl_prot) {
		ALOGE("%s: Could not get ctl for mixer commands", __func__);
		ret = -EINVAL;
		goto exit;
	}

	num_uc = mixer_ctl_get_num_enums(ctl_uc);
	default_uc = mixer_ctl_get_value(ctl_uc, 0);
	prot_en = mixer_ctl_get_value(ctl_prot, 0);

	for (i = 0; i < num_uc; i++) {
		/* Switch Usecase */
		mixer_ctl_set_value(ctl_uc, 0, i);

		/* Load TX Tuning Config (if available) */
		if (prot_en) {
			sprintf(filename, CRUS_TX_CONF_FILE, i);
			if (access(filename, R_OK) == 0)
				mixer_ctl_set_value(ctl_config, 0, 2);
			else
				ALOGE("%s: Tuning file not found (%s)",
				      __func__, filename);
		}

		/* Load RX Tuning Config (if available) */
		sprintf(filename, CRUS_RX_CONF_FILE, i);
		if (access(filename, R_OK) == 0)
			mixer_ctl_set_value(ctl_config, 0, 1);
		else
			ALOGE("%s: Tuning file not found (%s)", __func__,
			      filename);
	}

	/* Switch back to default usecase */
	mixer_ctl_set_value(ctl_uc, 0, default_uc);

	ALOGI("%s: Cirrus SP loaded available usecase configs", __func__);
exit:
	ALOGI("%s: Exit", __func__);

	return ret;
}

void *audio_extn_cirrus_initialization_thread()
{
	struct audio_device *adev = handle.adev_handle;
	struct audio_usecase *uc_info_rx = NULL;
	struct mixer_ctl *ctl;
	bool prot_en;
	int ret = 0;
	int32_t pcm_dev_rx_id, prev_state;
	bool det_en;

	pthread_mutex_lock(&handle.calibration_mutex);

	sleep(5);

	ALOGI("%s: PCM Stream thread", __func__);

	while(adev->platform == NULL) {
		sleep(1);
		ALOGI("%s: Waiting...", __func__);
	}

	prev_state = handle.state;
	handle.state = CALIBRATING;

	ctl = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_PROT_EN_MIXER);
	prot_en = mixer_ctl_get_value(ctl, 0);

	uc_info_rx = (struct audio_usecase *)calloc(1, sizeof(struct audio_usecase));
	if (!uc_info_rx) {
		ret = -EINVAL;
		goto exit;
	}

	uc_info_rx->id = USECASE_AUDIO_PLAYBACK_DEEP_BUFFER;
	uc_info_rx->type = PCM_PLAYBACK;
	uc_info_rx->in_snd_device = SND_DEVICE_NONE;
	uc_info_rx->stream.out = adev->crus_output;
	uc_info_rx->out_snd_device = SND_DEVICE_OUT_SPEAKER;
	list_add_tail(&adev->usecase_list, &uc_info_rx->list);

	enable_snd_device(adev, SND_DEVICE_OUT_SPEAKER);
	enable_audio_route(adev, uc_info_rx);
	pcm_dev_rx_id = platform_get_pcm_device_id(uc_info_rx->id, PCM_PLAYBACK);

	if (pcm_dev_rx_id < 0) {
		ALOGE("%s: Invalid pcm device for usecase (%d)",
		      __func__, uc_info_rx->id);
		ret = -ENODEV;
		goto exit;
	}

	handle.pcm_rx = pcm_open(adev->snd_card, pcm_dev_rx_id,
				 PCM_OUT, &pcm_config_cirrus_rx);

	if (handle.pcm_rx && !pcm_is_ready(handle.pcm_rx)) {
		ALOGE("%s: PCM device not ready: %s", __func__,
		      pcm_get_error(handle.pcm_rx));
		ret = -EINVAL;
		goto close_stream;
	}

	if (pcm_start(handle.pcm_rx) < 0) {
		ALOGE("%s: pcm start for RX failed; error = %s", __func__,
		      pcm_get_error(handle.pcm_rx));
		ret = -EINVAL;
		goto close_stream;
	}

	ALOGI("%s: PCM thread streaming", __func__);

	if (prot_en) {
		ret = audio_extn_cirrus_run_calibration();
		if (ret < 0) {
			ALOGE("%s: Calibration procedure failed (%d)", __func__, ret);
		}
	}

	ret = audio_extn_cirrus_load_usecase_configs();
	if (ret < 0) {
		ALOGE("%s: Set tuning configs failed (%d)", __func__, ret);
	}

close_stream:
	/*if (handle.pcm_tx){
		ALOGI("%s: pcm_tx_close", __func__);
		pcm_close(handle.pcm_tx);
		handle.pcm_tx = NULL;
	}*/
	if (handle.pcm_rx){
		ALOGI("%s: pcm_rx_close", __func__);
		pcm_close(handle.pcm_rx);
		handle.pcm_rx = NULL;
	}

	disable_snd_device(adev, SND_DEVICE_OUT_SPEAKER);
	disable_audio_route(adev, uc_info_rx);

exit:
	handle.state = (prev_state == PLAYBACK) ? PLAYBACK : IDLE;
	if (handle.state == PLAYBACK) {
		ctl = mixer_get_ctl_by_name(adev->mixer,
					    CRUS_SP_FAIL_DET_MIXER);
		det_en = mixer_ctl_get_value(ctl, 0);

		if (det_en && prot_en)
			(void)pthread_create(&handle.failure_detect_thread,
				     (const pthread_attr_t *) NULL,
				     audio_extn_cirrus_failure_detect_thread,
				     &handle);
	}

	pthread_mutex_unlock(&handle.calibration_mutex);

	ALOGI("%s: Exit", __func__);

	pthread_exit(0);
	return NULL;
}

void *audio_extn_cirrus_failure_detect_thread()
{
	const unsigned long r_scale_factor = 100000000;
	const unsigned long amp_factor = 71498;
	struct audio_device *adev = handle.adev_handle;
	struct crus_sp_ioctl_header header;
	struct mixer_ctl *ctl;
	struct crus_rx_get_temp_t live_data;
	int32_t buffer[96];
	int ret, dev_file;
	unsigned long rL, rR, zL, zR, rdL, rdR;
	bool left_cal_done, right_cal_done, proc_l, proc_r;
	bool det_en, prot_en;

	ALOGI("%s: Entry", __func__);

	ctl = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_PROT_EN_MIXER);
	prot_en = mixer_ctl_get_value(ctl, 0);

	if (!prot_en)
		goto exit;

	ctl = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_FAIL_DET_MIXER);
	det_en = mixer_ctl_get_value(ctl, 0);

	if (!det_en)
		goto exit;

	dev_file = open(CRUS_SP_FILE, O_RDWR | O_NONBLOCK);
	if (dev_file < 0) {
		ALOGE("%s: Failed to open Cirrus Playback IOCTL (%d)",
		      __func__, dev_file);
		goto exit;
	}

	header.size = sizeof(header);
	header.module_id = CRUS_MODULE_ID_RX;
	header.param_id = CRUS_PARAM_RX_GET_TEMP;
	header.data_length = CRUS_AFE_MAX_PARAMS;
	header.data = buffer;

	usleep(FAIL_DETECT_INIT_WAIT);

	pthread_mutex_lock(&handle.fb_prot_mutex);
	ret = ioctl(dev_file, CRUS_SP_IOCTL_GET, &header);
	pthread_mutex_unlock(&handle.fb_prot_mutex);
	if (ret < 0) {
		ALOGE("%s: Cirrus SP IOCTL failure (%d)",
		      __func__, ret);
		close(dev_file);
		goto exit;
	}

	memcpy(&live_data, buffer, sizeof(struct crus_rx_get_temp_t));

	zL = live_data.cal_z_l;
	zR = live_data.cal_z_r;

	left_cal_done = (live_data.cal_status_hp_l == 2) &&
			(live_data.cal_status_full_l == 2) &&
			(live_data.cal_z_l != CRUS_DEFAULT_CAL_L);

	right_cal_done = (live_data.cal_status_hp_r == 2) &&
			 (live_data.cal_status_full_r == 2) &&
			 (live_data.cal_z_r != CRUS_DEFAULT_CAL_R);

	if (left_cal_done) {
		ALOGI("%s: L Speaker Impedance: %lu.%08lu ohms", __func__,
		      zL * amp_factor / r_scale_factor,
		      zL * amp_factor % r_scale_factor);
		ALOGI("%s: L Calibration Temperature: %d C", __func__,
		      live_data.cal_amb_temp_l);
	} else
		ALOGE("%s: Left speaker uncalibrated", __func__);

	if (right_cal_done) {
		ALOGI("%s: R Speaker Impedance: %lu.%08lu ohms", __func__,
		      zR * amp_factor / r_scale_factor,
		      zR * amp_factor % r_scale_factor);
		ALOGI("%s: R Calibration Temperature: %d C", __func__,
		      live_data.cal_amb_temp_r);
	} else
		ALOGE("%s: Right speaker uncalibrated", __func__);

	if (!left_cal_done && !right_cal_done)
		goto exit;

	ALOGI("%s: Monitoring speaker impedance & temperature...", __func__);

	proc_l = true;
	proc_r = true;

	while ((handle.state == PLAYBACK) && det_en && (proc_l || proc_r)) {
		pthread_mutex_lock(&handle.fb_prot_mutex);
		ret = ioctl(dev_file, CRUS_SP_IOCTL_GET, &header);
		pthread_mutex_unlock(&handle.fb_prot_mutex);
		if (ret < 0) {
			ALOGE("%s: Cirrus SP IOCTL failure (%d)",
			      __func__, ret);
			goto loop;
		}

		memcpy(&live_data, buffer, sizeof(struct crus_rx_get_temp_t));

		if ((live_data.cal_z_l == 0) || (live_data.cal_z_r == 0))
			goto loop;

		zL = live_data.cal_z_l;
		zR = live_data.cal_z_r;
		rL = live_data.temp_l;
		rR = live_data.temp_r;

		rdL = (zL > rL ? (zL - rL) : (rL - zL)) * 100 / zL;
		rdR = (zR > rR ? (zR - rR) : (rR - zR)) * 100 / zR;

		if (left_cal_done && proc_l && (rL != 0) && (rdL > 60))
			ALOGI("%s: Left speaker impedance out of range (0x%lx) (%lu.%08lu ohms)",
			      __func__, rL, rL * amp_factor / r_scale_factor,
			      rL * amp_factor % r_scale_factor);

		if (right_cal_done && proc_r && (rR != 0) && (rdR > 60))
			ALOGI("%s: Right speaker impedance out of range (0x%lx) (%lu.%08lu ohms)",
			      __func__, rR, rR * amp_factor / r_scale_factor,
			      rR * amp_factor % r_scale_factor);

loop:
		det_en = mixer_ctl_get_value(ctl, 0);
		usleep(FAIL_DETECT_LOOP_WAIT);
	}

	close(dev_file);

exit:
	ALOGI("%s: Exit", __func__);

	pthread_exit(0);
	return NULL;
}

int audio_extn_cirrus_playback_enable(snd_device_t snd_device)
{
	struct audio_usecase *uc_info_tx;
	struct audio_device *adev = handle.adev_handle;
	struct mixer_ctl *ctl;
	int32_t pcm_dev_tx_id = -1, ret = 0;
	bool det_en, prot_en;

	if (!adev) {
		ALOGE("%s: Invalid params", __func__);
		return -EINVAL;
	}

	ctl = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_PROT_EN_MIXER);
	prot_en = mixer_ctl_get_value(ctl, 0);

	if (!prot_en)
		return 0;

	ALOGI("%s: Entry", __func__);

	uc_info_tx = (struct audio_usecase *)calloc(1, sizeof(struct audio_usecase));
	if (!uc_info_tx) {
		return -ENOMEM;
	}

	audio_route_apply_and_update_path(adev->audio_route,
					  platform_get_snd_device_name(snd_device));

	pthread_mutex_lock(&handle.fb_prot_mutex);
	uc_info_tx->id = USECASE_AUDIO_CIRRUS_PLAYBACK_TX;
	uc_info_tx->type = PCM_CAPTURE;
	uc_info_tx->in_snd_device = SND_DEVICE_IN_CAPTURE_CIRRUS_PLAYBACK;
	uc_info_tx->out_snd_device = SND_DEVICE_NONE;
	handle.pcm_tx = NULL;

	list_add_tail(&adev->usecase_list, &uc_info_tx->list);

	enable_snd_device(adev, SND_DEVICE_IN_CAPTURE_CIRRUS_PLAYBACK);
	enable_audio_route(adev, uc_info_tx);

	pcm_dev_tx_id = platform_get_pcm_device_id(uc_info_tx->id, PCM_CAPTURE);

	if (pcm_dev_tx_id < 0) {
		ALOGE("%s: Invalid pcm device for usecase (%d)",
		      __func__, uc_info_tx->id);
		ret = -ENODEV;
		goto exit;
	}

	handle.pcm_tx = pcm_open(adev->snd_card,
				 pcm_dev_tx_id,
				 PCM_IN, &pcm_config_cirrus_tx);

	if (handle.pcm_tx && !pcm_is_ready(handle.pcm_tx)) {
		ALOGD("%s: PCM device not ready: %s", __func__, pcm_get_error(handle.pcm_tx));
		ret = -EIO;
		goto exit;
	}

	if (pcm_start(handle.pcm_tx) < 0) {
		ALOGI("%s: pcm start for TX failed; error = %s", __func__,
		      pcm_get_error(handle.pcm_tx));
		ret = -EINVAL;
	}

	if (handle.state == IDLE) {
		ctl = mixer_get_ctl_by_name(adev->mixer,
					    CRUS_SP_FAIL_DET_MIXER);
		det_en = mixer_ctl_get_value(ctl, 0);

		if (det_en)
			(void)pthread_create(&handle.failure_detect_thread,
				     (const pthread_attr_t *) NULL,
				     audio_extn_cirrus_failure_detect_thread,
				     &handle);
	}

	handle.state = PLAYBACK;
exit:
	if (ret) {
		handle.state = IDLE;
		if (handle.pcm_tx) {
			ALOGI("%s: pcm_tx_close", __func__);
			pcm_close(handle.pcm_tx);
			handle.pcm_tx = NULL;
		}
		list_remove(&uc_info_tx->list);
		disable_snd_device(adev, SND_DEVICE_IN_CAPTURE_CIRRUS_PLAYBACK);
		disable_audio_route(adev, uc_info_tx);
		free(uc_info_tx);
	}

	pthread_mutex_unlock(&handle.fb_prot_mutex);
	ALOGI("%s: Exit", __func__);
	return ret;
}

void audio_extn_cirrus_playback_disable(snd_device_t snd_device)
{
	struct audio_usecase *uc_info_tx;
	struct audio_device *adev = handle.adev_handle;
	struct mixer_ctl *ctl;
	bool prot_en;

	if (!adev) {
		ALOGE("%s: Invalid params", __func__);
		return;
	}

	ctl = mixer_get_ctl_by_name(adev->mixer, CRUS_SP_PROT_EN_MIXER);
	prot_en = mixer_ctl_get_value(ctl, 0);

	if (!prot_en)
		return;

	ALOGI("%s: Entry", __func__);

	pthread_mutex_lock(&handle.fb_prot_mutex);

	handle.state = IDLE;

	uc_info_tx = get_usecase_from_list(adev, USECASE_AUDIO_CIRRUS_PLAYBACK_TX);
	if (!uc_info_tx) {
		ALOGE("%s: No TX usecase available", __func__);
		goto exit;
	}

	uc_info_tx->id = USECASE_AUDIO_CIRRUS_PLAYBACK_TX;
	uc_info_tx->type = PCM_CAPTURE;
	uc_info_tx->in_snd_device = SND_DEVICE_IN_CAPTURE_CIRRUS_PLAYBACK;
	uc_info_tx->out_snd_device = SND_DEVICE_NONE;
	if (handle.pcm_tx) {
		ALOGI("%s: pcm_tx_close", __func__);
		pcm_close(handle.pcm_tx);
		handle.pcm_tx = NULL;
	}

	disable_snd_device(adev, SND_DEVICE_IN_CAPTURE_CIRRUS_PLAYBACK);
	disable_audio_route(adev, uc_info_tx);

exit:
	pthread_mutex_unlock(&handle.fb_prot_mutex);

	audio_route_reset_path(adev->audio_route,
			       platform_get_snd_device_name(snd_device));

	ALOGI("%s: Exit", __func__);
}

#endif /* PLAYBACK */
